/* ============================================================
   JOÃO BEAUTY — cart.js
   Gerenciamento completo do carrinho de compras
   ============================================================ */

const CART_KEY = 'joao_beauty_cart';
const WA_NUMBER = '5562993403763';

/** Obtém o carrinho do localStorage */
function getCart() {
  try {
    return JSON.parse(localStorage.getItem(CART_KEY)) || [];
  } catch {
    return [];
  }
}

/** Salva o carrinho no localStorage */
function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

/** Adiciona produto ao carrinho */
function addToCart(produtoId, qty = 1) {
  const produto = allProducts.find(p => p.id === produtoId);
  if (!produto) return;

  const cart = getCart();
  const idx = cart.findIndex(i => i.id === produtoId);

  if (idx > -1) {
    cart[idx].qty += qty;
  } else {
    cart.push({
      id: produto.id,
      nome: produto.nome,
      colecao: produto.colecao,
      preco: produto.preco,
      preco_formatado: produto.preco_formatado,
      volume: produto.volume,
      categoria: produto.categoria,
      qty
    });
  }

  saveCart(cart);
  updateCartUI();
  openCartSidebar();
  showToast(`✓ ${produto.nome} adicionado ao carrinho`);
}

/** Remove produto do carrinho */
function removeFromCart(produtoId) {
  const cart = getCart().filter(i => i.id !== produtoId);
  saveCart(cart);
  updateCartUI();
  renderCartSidebar();
}

/** Atualiza quantidade */
function updateQty(produtoId, delta) {
  const cart = getCart();
  const idx = cart.findIndex(i => i.id === produtoId);
  if (idx === -1) return;

  cart[idx].qty = Math.max(1, cart[idx].qty + delta);
  saveCart(cart);
  updateCartUI();
  renderCartSidebar();
}

/** Calcula totais */
function getCartTotals() {
  const cart = getCart();
  const subtotal = cart.reduce((acc, i) => acc + i.preco * i.qty, 0);
  const totalItems = cart.reduce((acc, i) => acc + i.qty, 0);
  return { subtotal, total: subtotal, totalItems, cart };
}

/** Atualiza contador no header */
function updateCartUI() {
  const { totalItems } = getCartTotals();
  const counts = document.querySelectorAll('.cart-count');
  counts.forEach(el => {
    el.textContent = totalItems;
    el.classList.toggle('visible', totalItems > 0);
  });
}

/** Abre sidebar do carrinho */
function openCartSidebar() {
  const sidebar = document.getElementById('cartSidebar');
  const overlay = document.getElementById('cartOverlay');
  if (!sidebar) return;
  renderCartSidebar();
  sidebar.classList.add('open');
  if (overlay) overlay.classList.add('open');
  document.body.style.overflow = 'hidden';
}

/** Fecha sidebar do carrinho */
function closeCartSidebar() {
  const sidebar = document.getElementById('cartSidebar');
  const overlay = document.getElementById('cartOverlay');
  if (sidebar) sidebar.classList.remove('open');
  if (overlay) overlay.classList.remove('open');
  document.body.style.overflow = '';
}

/** Renderiza o conteúdo do sidebar do carrinho */
function renderCartSidebar() {
  const body = document.getElementById('cartBody');
  const footer = document.getElementById('cartFooter');
  if (!body) return;

  const { cart, subtotal, total, totalItems } = getCartTotals();

  if (cart.length === 0) {
    body.innerHTML = `
      <div class="cart-empty">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
          <circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle>
          <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
        </svg>
        <p>Seu carrinho está vazio</p>
        <button class="btn btn-outline" onclick="closeCartSidebar()">Explorar produtos</button>
      </div>
    `;
    if (footer) footer.innerHTML = '';
    return;
  }

  body.innerHTML = cart.map(item => `
    <div class="cart-item" id="cart-item-${item.id}">
      <div class="cart-item-img">
        ${getProductIcon(item.categoria)}
      </div>
      <div class="cart-item-info">
        <p class="cart-item-collection">${item.colecao}</p>
        <p class="cart-item-name">${item.nome}</p>
        <p class="cart-item-vol">${item.volume}</p>
        <div class="cart-item-qty">
          <button class="qty-btn" onclick="updateQty(${item.id}, -1)" aria-label="Diminuir">−</button>
          <span class="qty-val">${item.qty}</span>
          <button class="qty-btn" onclick="updateQty(${item.id}, 1)" aria-label="Aumentar">+</button>
        </div>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:8px;">
        <span class="cart-item-price">${formatPrice(item.preco * item.qty)}</span>
        <button class="cart-item-remove" onclick="removeFromCart(${item.id})" aria-label="Remover">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="3,6 5,6 21,6"></polyline>
            <path d="M19,6v14a2,2,0,0,1-2,2H7a2,2,0,0,1-2-2V6m3,0V4a1,1,0,0,1,1-1h4a1,1,0,0,1,1,1v2"></path>
          </svg>
        </button>
      </div>
    </div>
  `).join('');

  if (footer) {
    footer.innerHTML = `
      <div class="cart-summary">
        <div class="cart-summary-row">
          <span>Subtotal (${totalItems} ${totalItems === 1 ? 'item' : 'itens'})</span>
          <span>${formatPrice(subtotal)}</span>
        </div>
        <div class="cart-summary-row">
          <span>Frete</span>
          <span style="color:var(--verde);font-weight:600">A combinar</span>
        </div>
        <div class="cart-summary-row total">
          <span>Total</span>
          <span class="cart-total-val">${formatPrice(total)}</span>
        </div>
      </div>
      <button class="btn btn-whatsapp" style="width:100%;justify-content:center;font-size:.9rem;" onclick="checkoutWhatsApp()">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/>
        </svg>
        Finalizar pelo WhatsApp
      </button>
      <p style="text-align:center;font-size:.72rem;color:#999;margin-top:8px;">
        Você será redirecionado para o WhatsApp para finalizar seu pedido
      </p>
    `;
  }
}

/** Gera link de checkout para o WhatsApp */
function checkoutWhatsApp() {
  const { cart, total, totalItems } = getCartTotals();
  if (cart.length === 0) return;

  let msg = `Olá João! 👋\n\nGostaria de solicitar os seguintes produtos:\n\n`;

  cart.forEach(item => {
    msg += `• ${item.qty}x ${item.nome} — ${formatPrice(item.preco * item.qty)}\n`;
  });

  msg += `\n*Total: ${formatPrice(total)}*\n\nAguardo seu atendimento! 😊`;

  const url = `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(msg)}`;
  window.open(url, '_blank');
}

/** Formata preço em BRL */
function formatPrice(val) {
  return val.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

// Inicializa carrinho ao carregar página
document.addEventListener('DOMContentLoaded', () => {
  updateCartUI();
});
