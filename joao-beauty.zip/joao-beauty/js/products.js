/* ============================================================
   JOÃO BEAUTY — products.js
   Gerenciamento e renderização do catálogo de produtos
   ============================================================ */

let allProducts = [];

/**
 * Carrega os produtos do arquivo JSON
 */
async function loadProducts() {
  try {
    const res = await fetch('data/products.json');
    allProducts = await res.json();
    return allProducts;
  } catch (e) {
    console.error('Erro ao carregar produtos:', e);
    return [];
  }
}

/**
 * Renderiza um card de produto
 * @param {Object} produto 
 * @returns {string} HTML do card
 */
function renderProductCard(produto) {
  const favKey = `fav_${produto.id}`;
  const isFav = localStorage.getItem(favKey) === 'true';

  return `
    <article class="product-card" data-id="${produto.id}" data-category="${produto.categoria}">
      <div class="product-img-wrap">
        <div class="product-img-placeholder">
          ${getProductIcon(produto.categoria)}
          <span>${produto.colecao}</span>
        </div>
        <div class="product-badges">
          ${produto.novo ? '<span class="badge badge-novo">Novo</span>' : ''}
          ${produto.destaque ? '<span class="badge badge-destaque">Destaque</span>' : ''}
        </div>
        <button
          class="product-fav ${isFav ? 'active' : ''}"
          onclick="toggleFavorite(event, ${produto.id})"
          aria-label="Adicionar aos favoritos"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="${isFav ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2">
            <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
          </svg>
        </button>
        <div class="product-quick-view" onclick="openModal(${produto.id})">
          Ver detalhes →
        </div>
      </div>
      <div class="product-body">
        <p class="product-collection">${produto.colecao}</p>
        <h3 class="product-name">${produto.nome}</h3>
        <p class="product-desc">${produto.descricao_curta}</p>
        <p class="product-volume">${produto.volume}</p>
        <div class="product-price-block">
          <span class="product-price">${produto.preco_formatado}</span>
        </div>
        <p class="product-installments">${produto.parcelamento}</p>
        <div class="product-actions">
          <button class="btn-cart" onclick="addToCart(${produto.id})">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle>
              <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
            </svg>
            Adicionar
          </button>
          <a
            href="${buildWhatsAppLink(produto)}"
            target="_blank"
            rel="noopener"
            class="btn-wa-card"
            aria-label="Comprar via WhatsApp"
            title="Comprar via WhatsApp"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/>
            </svg>
          </a>
        </div>
      </div>
    </article>
  `;
}

/**
 * Ícone SVG por categoria
 */
function getProductIcon(categoria) {
  const icons = {
    seruns: `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><path d="M12 2C8 2 6 6 6 9c0 4 2 7 6 9 4-2 6-5 6-9 0-3-2-7-6-7z"/><line x1="12" y1="2" x2="12" y2="1"/></svg>`,
    hidratacao: `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/></svg>`,
    limpeza: `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9,22 9,12 15,12 15,22"/></svg>`,
    corpo: `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><circle cx="12" cy="5" r="2"/><path d="M12 7v10m-4-5h8"/></svg>`,
    fragrancias: `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><path d="M8 3h8a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M10 3V1h4v2"/><line x1="12" y1="7" x2="12" y2="14"/></svg>`,
    skincare: `<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>`
  };
  return icons[categoria] || icons.skincare;
}

/**
 * Monta link do WhatsApp para produto individual
 */
function buildWhatsAppLink(produto, qty = 1) {
  const phone = '5562993403763';
  const msg = encodeURIComponent(
    `Olá João! 👋\n\nGostaria de solicitar o seguinte produto:\n\n` +
    `• ${qty}x ${produto.nome} — ${produto.preco_formatado}\n\n` +
    `Aguardo seu atendimento! 😊`
  );
  return `https://wa.me/${phone}?text=${msg}`;
}

/**
 * Toggle favorito
 */
function toggleFavorite(e, produtoId) {
  e.stopPropagation();
  const btn = e.currentTarget;
  const key = `fav_${produtoId}`;
  const isFav = localStorage.getItem(key) === 'true';
  localStorage.setItem(key, (!isFav).toString());
  btn.classList.toggle('active', !isFav);
  const svgPath = btn.querySelector('path');
  if (svgPath) {
    svgPath.setAttribute('fill', !isFav ? 'currentColor' : 'none');
  }
  showToast(!isFav ? '❤️ Adicionado aos favoritos' : 'Removido dos favoritos');
}

/**
 * Filtra e ordena produtos
 */
function filterProducts(products, { categoria = 'todos', search = '', sort = 'relevancia', minPrice = 0, maxPrice = Infinity } = {}) {
  let result = [...products];

  if (categoria && categoria !== 'todos') {
    result = result.filter(p => p.categoria === categoria || p.colecao.toLowerCase() === categoria);
  }

  if (search) {
    const q = search.toLowerCase();
    result = result.filter(p =>
      p.nome.toLowerCase().includes(q) ||
      p.descricao_curta.toLowerCase().includes(q) ||
      p.colecao.toLowerCase().includes(q) ||
      p.tags.some(t => t.includes(q))
    );
  }

  result = result.filter(p => p.preco >= minPrice && p.preco <= maxPrice);

  switch (sort) {
    case 'preco-asc':  result.sort((a, b) => a.preco - b.preco); break;
    case 'preco-desc': result.sort((a, b) => b.preco - a.preco); break;
    case 'avaliacao':  result.sort((a, b) => b.avaliacao - a.avaliacao); break;
    case 'nome':       result.sort((a, b) => a.nome.localeCompare(b.nome)); break;
    default:
      result.sort((a, b) => (b.destaque ? 1 : 0) - (a.destaque ? 1 : 0));
  }

  return result;
}

/**
 * Modal de detalhe do produto
 */
function openModal(produtoId) {
  const produto = allProducts.find(p => p.id === produtoId);
  if (!produto) return;

  const overlay = document.getElementById('productModal');
  if (!overlay) return;

  overlay.innerHTML = `
    <div class="modal" role="dialog" aria-modal="true" aria-label="${produto.nome}">
      <button class="modal-close" onclick="closeModal()" aria-label="Fechar">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
      <div class="modal-inner">
        <div class="modal-img">
          ${getProductIcon(produto.categoria)}
        </div>
        <div class="modal-body">
          <p class="modal-collection">${produto.colecao}</p>
          <h2 class="modal-name">${produto.nome}</h2>
          <div class="modal-rating">
            <span class="stars">${'★'.repeat(Math.round(produto.avaliacao))}${'☆'.repeat(5 - Math.round(produto.avaliacao))}</span>
            <span style="font-size:.8rem;color:#999">${produto.avaliacao} (${produto.num_avaliacoes.toLocaleString('pt-BR')} avaliações)</span>
          </div>
          <p class="modal-desc">${produto.descricao_completa}</p>
          <div class="modal-benefits">
            ${produto.beneficios.map(b => `<div class="modal-benefit">${b}</div>`).join('')}
          </div>
          <div class="modal-info">
            <div class="modal-info-row">
              <span class="modal-info-label">Volume</span>
              <span class="modal-info-val">${produto.volume}</span>
            </div>
            <div class="modal-info-row">
              <span class="modal-info-label">Ingredientes</span>
              <span class="modal-info-val">${produto.ingredientes}</span>
            </div>
            <div class="modal-info-row">
              <span class="modal-info-label">Modo de uso</span>
              <span class="modal-info-val">${produto.modo_uso}</span>
            </div>
          </div>
          <p class="modal-price">${produto.preco_formatado}</p>
          <p class="modal-install">${produto.parcelamento}</p>
          <div class="modal-actions">
            <button class="btn btn-primary" onclick="addToCart(${produto.id}); closeModal()">
              Adicionar ao carrinho
            </button>
            <a href="${buildWhatsAppLink(produto)}" target="_blank" rel="noopener" class="btn btn-whatsapp">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/>
              </svg>
              Comprar via WhatsApp
            </a>
          </div>
        </div>
      </div>
    </div>
  `;

  overlay.classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  const overlay = document.getElementById('productModal');
  if (overlay) {
    overlay.classList.remove('open');
    document.body.style.overflow = '';
  }
}

// Fechar modal ao clicar no fundo
document.addEventListener('click', (e) => {
  if (e.target.id === 'productModal') closeModal();
});

// ESC fecha modal
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') { closeModal(); closeSearch(); }
});
