/* ============================================================
   JOÃO BEAUTY — search.js
   Busca instantânea de produtos
   ============================================================ */

let searchTimeout = null;

/** Abre overlay de busca */
function openSearch() {
  const overlay = document.getElementById('searchOverlay');
  if (!overlay) return;
  overlay.classList.add('open');
  document.body.style.overflow = 'hidden';
  setTimeout(() => {
    const input = document.getElementById('searchInput');
    if (input) input.focus();
  }, 100);
}

/** Fecha overlay de busca */
function closeSearch() {
  const overlay = document.getElementById('searchOverlay');
  if (!overlay) return;
  overlay.classList.remove('open');
  document.body.style.overflow = '';
  const input = document.getElementById('searchInput');
  if (input) input.value = '';
  renderSearchResults([]);
}

/** Handler do input de busca (com debounce) */
function onSearchInput(e) {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => {
    const q = e.target.value.trim();
    if (q.length < 2) {
      renderSearchResults([]);
      return;
    }
    const results = filterProducts(allProducts, { search: q });
    renderSearchResults(results.slice(0, 6));
  }, 200);
}

/** Renderiza resultados da busca */
function renderSearchResults(results) {
  const container = document.getElementById('searchResults');
  if (!container) return;

  if (results.length === 0) {
    const q = document.getElementById('searchInput')?.value || '';
    container.innerHTML = q.length >= 2
      ? `<div class="search-empty">
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="color:#ccc;margin-bottom:8px">
            <circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line>
          </svg>
          <p>Nenhum produto encontrado para "<strong>${q}</strong>"</p>
        </div>`
      : '';
    return;
  }

  container.innerHTML = results.map(p => `
    <div class="search-result-item" onclick="openModal(${p.id}); closeSearch();">
      <div class="search-result-thumb">
        ${getProductIcon(p.categoria)}
      </div>
      <div>
        <p class="search-result-name">${p.nome}</p>
        <p style="font-size:.72rem;color:#999;margin:2px 0">${p.colecao} · ${p.volume}</p>
        <p class="search-result-price">${p.preco_formatado}</p>
      </div>
    </div>
  `).join('');
}

// Fechar ao clicar no fundo
document.addEventListener('click', (e) => {
  if (e.target.id === 'searchOverlay') closeSearch();
});

// Inicializa input ao carregar
document.addEventListener('DOMContentLoaded', () => {
  const input = document.getElementById('searchInput');
  if (input) input.addEventListener('input', onSearchInput);
});
